package networks;

import java.io.*; 
import java.net.*; 
public class TCPClient {
	
	static Socket clientSocket;
	    public static void main(String argv[]) throws Exception 
	    { 
	        String sentence; 
	        String modifiedSentence; 

	        BufferedReader inFromUser =   new BufferedReader(new InputStreamReader(System.in)); 

	        
	        sentence = inFromUser.readLine(); 
            if(sentence.equals("CONNECT")){
            	
	        //to connect with different laptops change this ip address 
		        clientSocket = new Socket("127.0.0.1", 6789); 
	
		        DataOutputStream outToServer = new DataOutputStream(clientSocket.getOutputStream()); 
		        BufferedReader inFromServer = new BufferedReader(new InputStreamReader(clientSocket.getInputStream())); 
	          
        	  System.out.println("connection established");

        	  System.out.print("FROM CLIENT: "); 
        	  sentence = inFromUser.readLine();
	          outToServer.writeBytes(sentence + '\n'); 
        	  
        	  while(true){
        		  modifiedSentence = inFromServer.readLine();
		          System.out.println("FROM SERVER: " + modifiedSentence);
		          
		          System.out.print("FROM CLIENT: "); 
        		  sentence = inFromUser.readLine();
        		  if(sentence.equals("disconnect")){
        			  System.out.println("Disconnecting ya AMAARRRRR");
    		          outToServer.writeBytes(sentence + '\n'); 
    		          outToServer.close();
    		          break;
        		  }//else {
          		//if (inFromUser.ready()){
              	
          		//sentence= inFromUser.readLine();

          		//}
          	//if (inFromServer.ready()){
          		//modifiedSentence = inFromServer.readLine(); 
          	   
          	
          	//}
                 
          	//}
		          outToServer.writeBytes(sentence + '\n'); 
		         
        	  }
          	
            }
           
          else{
        	  System.out.println("connection refused");
	      }
	 } 
}
