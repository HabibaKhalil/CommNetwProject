package networks;
import java.io.*; 
import java.net.*;
public class TCPServer {
	
	public static void main(String argv[]) throws Exception 
	{ 
		String clientSentence; 
		String capitalizedSentence; 

		ServerSocket welcomeSocket = new ServerSocket(6789); 

		Socket connectionSocket = welcomeSocket.accept(); 

		BufferedReader inFromUser = new BufferedReader(new InputStreamReader(System.in));

		BufferedReader inFromClient;

		DataOutputStream  outToClient;

		while(true){

			inFromClient = new BufferedReader(new  InputStreamReader(connectionSocket.getInputStream()));

			outToClient = new DataOutputStream(connectionSocket.getOutputStream());

			clientSentence = inFromClient.readLine();
			System.out.println("From Client: " + clientSentence);
			if(clientSentence.equals("disconnect")){
				System.out.println("Disconnecting ya AMAARRRRR");
				outToClient.close();
				break;
			}
			//}
			//  while(true){
				//if (inFromClient.ready()){
				  //if(inFromServer.ready()){
                	

            		//clientSentence= inFromClient.readLine();
            		
            		//answerFromServer=inFromServer.readLine();
                   //capitalizedSentence = clientSentence.toUpperCase() + '\n'; 
				  // outToClient.writeBytes(capitalizedSentence); 
            		//outToClient.writeBytes(answerFromServer);
             
            		//}
			 // }

			System.out.print("From Server: ");
			capitalizedSentence = inFromUser.readLine() + '\n';

			//System.out.print(capitalizedSentence);

			outToClient.writeBytes(capitalizedSentence);
		}
	}
}
